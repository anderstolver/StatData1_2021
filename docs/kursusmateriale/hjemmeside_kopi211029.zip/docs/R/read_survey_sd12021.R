# indlæsning af data indsamlet via Absalon ved en anden forelæsning 8/9-2021

library(readxl)
library(tidyverse)
library(stringr)


data <- read_tsv("../data/introquiz.tsv")
my_data <- select(data, Date, Farve, Studie, Forventning, Hjemmeside
                  , Rosiner, Karakter, Video, R, Opgaver, Sprit
                  , Klogeste, Studiejob, Fritid, Punkter)

# check variablen Farve

count(my_data, Farve)

# check variablen Studie

count(my_data, Studie)

# check variablen Forventing

count(my_data, Forventning)

# check variable Hjemmeside

count(my_data, Hjemmeside)

# check variable Rosiner

count(my_data, Rosiner)

# check variable Karakter

count(my_data, Karakter)

# check variable Video

count(my_data, Video)

# check variable R

count(my_data, R)

# check variable Opgaver

count(my_data, Opgaver)

# check variable Sprit

count(my_data, Sprit)

# check variable Klogeste

count(my_data, Klogeste)

# ret variablen Studiejob til numerisk variable

unique(my_data$Studiejob)
my_data$Studiejob <- str_replace_all(my_data$Studiejob
                      , c("0-20 timer" = "10"
                          , "12-16" = "14"
                          , "5,5" = "5.5"
                          , "0 timer" = "0"
                          , "96" = NA
                          , "0-15 timer" = "7.5"
                          , "0 timer brr" = "0"
                          , "nul" = "0"
                          , "ingen" = "0"
                          , "max 15" = "7.5"
                          , "6,5" = "6.5"
                          , "15-20" = "17.5"
                          , "7,5" = "7.5"
                          , "Nul" = "0"
                          , "10-15 timer" = "12.5"
                          , "0-10" = "5"
                          , "10-15" = "12.5"
                          , "15 timer" = "15"))
unique(my_data$Studiejob)
my_data$Studiejob <- str_replace(my_data$Studiejob, "0 brr", "0")
unique(my_data$Studiejob)
my_data <- mutate(my_data, job = as.numeric(Studiejob))
my_data$job

# ret antal punktet til numerisk variable

my_data$Punkter <- replace(my_data$Punkter, my_data$Punkter == "mere end 5", NA)
my_data$Punkter <- replace(my_data$Punkter, my_data$Punkter == "42 - meningen med livet", NA)
my_data$Punkter <- replace(my_data$Punkter, my_data$Punkter == "0", NA)
my_data <- mutate(my_data, Punkter = as.numeric(Punkter))

my_data <- mutate(my_data, traer = str_detect(Fritid, "Klatre i træer"))
my_data <- mutate(my_data, kantarel = str_detect(Fritid, "Plukke kantareller"))
my_data <- mutate(my_data, fodbold = str_detect(Fritid, "Se fodboldkampe med Liverpool i tv"))
my_data <- mutate(my_data, renovere_bolig = str_detect(Fritid, "Renovere sin bolig"))
my_data <- mutate(my_data, rulleski = str_detect(Fritid, "Køre på rulleski"))
my_data <- mutate(my_data, haekle = str_detect(Fritid, "Hækle"))

my_data <- select(my_data, -Fritid)

# lav grovere inddeling af variablen karakter

my_data <- mutate(my_data, nykar = fct_recode(factor(Karakter), "00-4" = "00 eller -3", "00-4" = "2", "00-4" = "2", "00-4" = "4", "10-12" = "10", "10-12" = "12", NULL = "Det ønsker jeg ikke at svare på"))

# fjern datalinjer med meget få svar

my_data$antal_NAs <- apply(my_data, 1, function(z){sum(is.na(z))})
my_data <- filter(my_data, antal_NAs < 2) %>%
  select(-antal_NAs)

# eksporter rensede data

write_tsv(my_data, file = "../data/introquiz_renset.txt")

# check indlæsning af data

my_data <- read.table("../data/introquiz_renset.txt", header = T, sep = "\t")
dim(my_data)
names(my_data)
head(my_data)
