library(readr)
library(ggplot2)
library(tidyverse)

my_data <- read_tsv("../data/birds.txt", col_names = F, skip = 1)
names(my_data) <- c("country", "species", "rank", "threatened")
head(my_data)
my_data <- select(my_data, country, species, threatened)
ggplot(data = my_data) + geom_point(aes(x = species, y = threatened))

my_data2 <- read_tsv("../data/birthrates.txt", col_names = F, skip = 0)
head(my_data2)
names(my_data2) <- c("rank2", "country", "brate")

my_data3 <- read_tsv("../data/area.txt", col_names = F, skip = 0)
head(my_data3)
names(my_data3) <- c("rank3", "country", "area", "area_miles2","landarea", "landarea_miles", "pct_world")
my_data3 <- select(country, area, landarea)

data <- left_join(my_data2, my_data) %>%
  left_join(my_data3) %>%
  mutate(density = 1000 * species / area)

head(data)
ggplot(data = data) + geom_point(aes(x = brate, y = density))  + scale_y_log10()
data
data$brate

names(my_data)
