library(MASS)
data(cats)
head(cats, 3)
Bwt
cats$Bwt
mean(cats$Bwt)
