library(MASS)
data(cats)
cats
cats$Bwt
# fortæller at Bwt ligger i datasættet cats
mean(cats$Bwt)
