library(readxl)
?read_excel
my_data <- read_excel("../data/johnson-fatpct.xlsx")
my_data
