my_data <- read.table(file = "../data/gaet8.txt")
my_data
names(my_data) <- c("farve", "gaet")
hist(my_data$gaet)
qqnorm(my_data$gaet)
mean(my_data$gaet)
sd(my_data$gaet)
abline(a = mean(my_data$gaet), b = sd(my_data$gaet))
