sudokuData <- read.table(file = "sudoku-sd1.txt", header = T)
sudokuData <- transform(sudokuData, tid = 60 * min + sek)
sudokuData <- transform(sudokuData, type = factor(type))

library(tidyverse)
summarise(group_by(sudokuData, type), mean_tid = mean(tid, na.rm = T)
          , sd_tid = sd(tid, na.rm = T))


